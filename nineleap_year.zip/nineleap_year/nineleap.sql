/*
SQLyog - Free MySQL GUI v5.02
Host - 5.0.19-nt : Database - nineleapyear
*********************************************************************
Server version : 5.0.19-nt
*/


create database if not exists `nineleapyear`;

USE `nineleapyear`;

/*Table structure for table `answer` */

DROP TABLE IF EXISTS `answer`;

CREATE TABLE `answer` (
  `Answer_ID` int(11) NOT NULL auto_increment,
  `Answer` varchar(255) default NULL,
  `Question_ID` int(11) default NULL,
  PRIMARY KEY  (`Answer_ID`),
  KEY `FKABCA3FBEE2FF2433` (`Question_ID`),
  CONSTRAINT `FKABCA3FBEE2FF2433` FOREIGN KEY (`Question_ID`) REFERENCES `questions` (`QUESTION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `answer` */

insert into `answer` values 
(1,'a',1),
(2,'s',1),
(3,'r',1),
(4,'g',1);

/*Table structure for table `emp` */

DROP TABLE IF EXISTS `emp`;

CREATE TABLE `emp` (
  `eid` int(11) NOT NULL auto_increment,
  `edesignation` varchar(255) default NULL,
  `ename` varchar(255) default NULL,
  `manager_eid` int(11) default NULL,
  PRIMARY KEY  (`eid`),
  KEY `FK188C8D5E41A80` (`manager_eid`),
  CONSTRAINT `FK188C8D5E41A80` FOREIGN KEY (`manager_eid`) REFERENCES `emp` (`eid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `emp` */

insert into `emp` values 
(1,'ceo','BharathVijay',NULL),
(2,'coo','kp',1),
(3,'manager(head)','Subhra',2),
(4,'Developer','Gautham',3),
(5,'front Developer','Sathish',3),
(6,'tester','Vijaya',3),
(7,'Qualityhead','kudli',2),
(8,'manager(Scrum)','SaiKumar',2),
(9,'ceo','BharathVijay',NULL),
(10,'coo','kp',9),
(11,'Qualityhead','kudli',10),
(12,'manager(Scrum)','SaiKumar',10),
(13,'ceo','BharathVijay',NULL),
(14,'coo','kp',13),
(15,'Qualityhead','kudli',14),
(16,'manager(Scrum)','SaiKumar',14);

/*Table structure for table `emp_table` */

DROP TABLE IF EXISTS `emp_table`;

CREATE TABLE `emp_table` (
  `eid` int(11) NOT NULL auto_increment,
  `designation` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `manager_eid` int(11) default NULL,
  PRIMARY KEY  (`eid`),
  KEY `FK87467197138971A3` (`manager_eid`),
  CONSTRAINT `FK87467197138971A3` FOREIGN KEY (`manager_eid`) REFERENCES `emp_table` (`eid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `emp_table` */

insert into `emp_table` values 
(1,'ceo','Adam',NULL),
(2,'coo','madhu',1),
(3,'Sw-Tester','GAuthum',2),
(4,'manager','saba',3),
(5,'tester','aa',3),
(6,'developer','cc',3),
(7,'t','gg',5),
(8,'ii','hh',5);

/*Table structure for table `emp_tablejsp` */

DROP TABLE IF EXISTS `emp_tablejsp`;

CREATE TABLE `emp_tablejsp` (
  `eid` int(11) NOT NULL auto_increment,
  `edesig` varchar(255) default NULL,
  `ename` varchar(255) default NULL,
  `manager_eid` int(11) default NULL,
  PRIMARY KEY  (`eid`),
  KEY `FK1E9E2F50AA50C101` (`manager_eid`),
  CONSTRAINT `FK1E9E2F50AA50C101` FOREIGN KEY (`manager_eid`) REFERENCES `emp_tablejsp` (`eid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `emp_tablejsp` */

insert into `emp_tablejsp` values 
(1,'ceo','RAM',NULL),
(2,'coo','Raj',1),
(3,'Manager Marketing','adam',2),
(4,'L&D Manager','nikhal',3),
(5,'Developer','tippu',4),
(6,'Developer','sadam',2),
(7,'Developer','sadam',2),
(8,'Developer','sadam',2),
(9,'Developer','akshay',3),
(10,'tester','RAjaKUmar',1);

/*Table structure for table `employee` */

DROP TABLE IF EXISTS `employee`;

CREATE TABLE `employee` (
  `id` int(11) NOT NULL auto_increment,
  `desgnation` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `manager_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK4AFD4ACE650B73BA` (`manager_id`),
  CONSTRAINT `FK4AFD4ACE650B73BA` FOREIGN KEY (`manager_id`) REFERENCES `employee` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `employee` */

insert into `employee` values 
(1,'ceo','RAM',NULL),
(2,'coo','Raj',1),
(3,NULL,NULL,NULL),
(4,'L&D Manager','nikhal',3),
(5,'jjj','saba',3),
(6,'hhh','jjjyyy',5),
(7,'jj','uu',2),
(8,'hhh','ll',3),
(9,'kk','ooo',1),
(10,'kk','gou',9),
(11,'lkl','.kjk',3),
(12,'gggg','adam',3);

/*Table structure for table `employeedto` */

DROP TABLE IF EXISTS `employeedto`;

CREATE TABLE `employeedto` (
  `eid` int(11) NOT NULL auto_increment,
  `designation` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `manager_eid` int(11) default NULL,
  PRIMARY KEY  (`eid`),
  KEY `FK99E52831138971A3` (`manager_eid`),
  CONSTRAINT `FK99E52831138971A3` FOREIGN KEY (`manager_eid`) REFERENCES `employeedto` (`eid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `employeedto` */

insert into `employeedto` values 
(1,'ceo','A',NULL),
(2,'coo','B',1),
(3,'Qa-manager','c',2),
(4,'Qa-tester','RAj',3),
(5,'Qa-developer','RAm',4),
(6,'Sw-Tester','GAuthum',3),
(7,'Sw-Developer','madhu',3);

/*Table structure for table `questions` */

DROP TABLE IF EXISTS `questions`;

CREATE TABLE `questions` (
  `QUESTION_ID` int(11) NOT NULL auto_increment,
  `QUESTION` varchar(255) default NULL,
  `SURVEY_ID` int(11) default NULL,
  PRIMARY KEY  (`QUESTION_ID`),
  KEY `FK95C5414DD76DB9F3` (`SURVEY_ID`),
  CONSTRAINT `FK95C5414DD76DB9F3` FOREIGN KEY (`SURVEY_ID`) REFERENCES `survey` (`SURVEY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `questions` */

insert into `questions` values 
(1,'aa',1);

/*Table structure for table `survey` */

DROP TABLE IF EXISTS `survey`;

CREATE TABLE `survey` (
  `SURVEY_ID` int(11) NOT NULL auto_increment,
  `END_DATE` datetime default NULL,
  `START_DATE` datetime default NULL,
  `STATUS` varchar(255) default NULL,
  `SURVEY_NAME` varchar(255) default NULL,
  PRIMARY KEY  (`SURVEY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `survey` */

insert into `survey` values 
(1,'2015-11-20 00:00:00','2015-11-12 00:00:00','Completed','adam');



import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

import com.nineleaps.app.dto.EmployeeDto;


public class Main {

	public static void main(String[] args) {
		
		
		AnnotationConfiguration configuration=new AnnotationConfiguration();
		configuration.configure();
		SessionFactory factory=configuration.buildSessionFactory();
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		
			
			transaction.begin();
			
		/*Employee emp4=	(Employee) session.get(Employee.class, 4);
		
		
		
		Employee e5=new Employee();
		e5.setName("Saba");
		e5.setDesgnation("tester");
		e5.setManager(emp4);
		
		session.save(e5);*/
		EmployeeDto e=new EmployeeDto();
			e.setName("RAM");
			e.setDesgnation("ceo");
			
			
			EmployeeDto e1=new EmployeeDto();
			e1.setName("Raj");
			e1.setDesgnation("coo");
			e1.setManager(e);
			
			EmployeeDto e2=new EmployeeDto();
			e2.setName("adam");
			e2.setDesgnation("Manager Marketing");
			e2.setManager(e1);
			
			EmployeeDto e3=new EmployeeDto();
			e3.setName("nikhal");
			e3.setDesgnation("L&D Manager");
			e3.setManager(e2);
			
			session.save(e3);
			//Query query=session.createQuery("From EmployeeDto");
     /* List<EmployeeDto>   di=   query.list();
      System.out.println(di.size());
      
      for(EmployeeDto employee:di)
		{
			
			System.out.println(employee);
		}*/
			//Query query=session.createQuery("From Employee");
			//query.setString("desgnation", "Manager Marketing");
			//int modifications=query.executeUpdate();
			//List<Employee> li=query.list();
/*
			for(Employee employee:li)
			{
				
				System.out.println(employee);
			}*/
			/* for(Iterator it=query.iterate();it.hasNext();)  
			  {  
			   Employee user = (Employee)it.next();  
			   System.out.println("User Name: " + user.getName());  
			   System.out.println("User Id: " + user.getId());  
			  }  */
			
			transaction.commit();
		session.close();
	}

}

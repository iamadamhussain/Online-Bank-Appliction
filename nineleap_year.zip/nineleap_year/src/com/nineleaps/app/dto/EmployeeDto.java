package com.nineleaps.app.dto;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
public class EmployeeDto {

	@Id
	@GeneratedValue
	
	private int eid;
	@Column(name="ename")

	private  String name;
	@Column(name="edesig")

	private String desgnation;
/*	@Column(name="emanager")
*/@ManyToOne(cascade=CascadeType.ALL)
	private EmployeeDto manager;
	

	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
	public String getDesgnation() {
		return desgnation;
	}
	public void setDesgnation(String desgnation) {
		this.desgnation = desgnation;
	}
	public EmployeeDto getManager() {
		return manager;
	}
	public void setManager(EmployeeDto manager) {
		this.manager = manager;
	}
	public EmployeeDto() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return name;
				}
	

	
}

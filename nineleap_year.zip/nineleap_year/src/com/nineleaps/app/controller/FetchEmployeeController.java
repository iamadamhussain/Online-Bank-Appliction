package com.nineleaps.app.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nineleaps.app.dto.EmployeeDto;
import com.nineleaps.app.model.service.EmployeeService;

public class FetchEmployeeController  extends HttpServlet{

	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		EmployeeService employeeService=new EmployeeService();
		List<EmployeeDto> listofemp = employeeService.getEmployeesTree();
		System.out.println(listofemp.size());
		
		RequestDispatcher dispatcher=null;
		
		
		/*if(res==1)
			
		{
			*/
		req.setAttribute("listofemptree", listofemp);
		
		dispatcher=req.getRequestDispatcher("home.jsp");
		/*}else {*/
			
	/*		req.setAttribute("listemp", listofemp);
	*/
			//dispatcher=req.getRequestDispatcher("reg.jsp");

		//}
		dispatcher.forward(req, resp);
		
	}
}

package com.nineleaps.app.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nineleaps.app.dto.EmployeeDto;
import com.nineleaps.app.model.service.EmployeeService;

public class EmployeeController  extends HttpServlet{

	EmployeeService service;
	public EmployeeController() {
service=new EmployeeService();
	
	}
	
/*	 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {*/
	 /*       String forward="";
	        String action = request.getParameter("action");

	        if (action.equalsIgnoreCase("delete")){
	            int userId = Integer.parseInt(request.getParameter("userId"));
	            dao.deleteUser(userId);
	            forward = LIST_USER;
	            request.setAttribute("users", dao.getAllUsers());    
	        } else if (action.equalsIgnoreCase("edit")){
	            forward = INSERT_OR_EDIT;
	            int userId = Integer.parseInt(request.getParameter("userId"));
	            User user = dao.getUserById(userId);
	            request.setAttribute("user", user);
	        } else if (action.equalsIgnoreCase("listUser")){
	            forward = LIST_USER;
	            request.setAttribute("users", dao.getAllUsers());
	        } else {
	            forward = INSERT_OR_EDIT;
	        }

	        RequestDispatcher view = request.getRequestDispatcher(forward);
	        view.forward(request, response);
	    }

*/
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
	
List<EmployeeDto>	listofemp=service.getEmployees();	
		System.out.println(listofemp);
	
		//fetching data from UI
String name=	req.getParameter("name");//FROM TEXTBOX
	String desig=	req.getParameter("designation");//FROM TEXTBOX
	//String manager=	req.getParameter("manager");
	String empid=req.getParameter("manager");//FROM SELECT BOX
	
	//
EmployeeDto eid= service.getEmpbyId(Integer.parseInt(empid));

System.out.println(eid+"inside controller");
	//creating dto obj and setting
EmployeeDto dto=new EmployeeDto();
dto.setName(name);
dto.setDesgnation(desig);
//getting managerid
dto.setManager(eid);

	
	
	
		 service=new EmployeeService();
		//passing dto obj to service
	int res=	service.saveEmp(dto);
	System.out.println("back"+res);
	RequestDispatcher dispatcher=null;
	
	
	if(res==1)
		
	{
		dispatcher=req.getRequestDispatcher("reg.jsp");
	}else {
		
		/*req.setAttribute("listemp", listofemp);*/

		dispatcher=req.getRequestDispatcher("reg.jsp");

	}
	dispatcher.forward(req, resp);
		
		
	}
	
}

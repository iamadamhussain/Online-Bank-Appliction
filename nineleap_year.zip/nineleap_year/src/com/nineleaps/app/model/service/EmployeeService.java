package com.nineleaps.app.model.service;

import java.util.List;

import com.nineleaps.app.dto.EmployeeDto;
import com.nineleaps.app.model.dao.EmployeeDao;

public class EmployeeService {
EmployeeDao dao=new EmployeeDao();
	




/*public List<EmployeeDto> getEmployeesTree() {
	return dao.getEmployeestree1();
}*/

/*public List<EmployeeDto> getEmployeesTree2(int mnagerId) {
	return dao.getEmployeesF(mnagerId);
}*/
	public int saveEmp(EmployeeDto dto)
	{
		
		int result=dao.saveEmp(dto);
		
		return result;
		
		
		
	}
	
	
	public List<EmployeeDto> getEmployees() {
		return dao.getEmployees();
	}

	
	public EmployeeDto getEmpbyId(int empid)
	{
		
		EmployeeDto result=dao.getEmployeebyId(empid);
		
		return result;
		
		
		
	}
	
	
}

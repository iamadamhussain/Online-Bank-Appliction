package com.nineleaps.app.model.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.nineleaps.app.dto.EmployeeDto;

public class EmployeeDao {

	
    
//to save employees
	public int saveEmp(EmployeeDto dto)
	{ 
		
	Configuration configuration=new Configuration();
	configuration.configure();
		
		SessionFactory factory=configuration.buildSessionFactory();
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		
	int sid=(int) session.save(dto);
		
		System.out.println("data entered succefully "+sid);
		transaction.commit();
		session.close();
		
		
		
		
		return 1;
		
		
		
	}
	//to get listofemployee
	public List<EmployeeDto> getEmployees() {
		

		Configuration configuration
		=new Configuration();
		configuration.configure();
		
		SessionFactory factory=configuration.buildSessionFactory();	
		Session session=factory.openSession();
		Transaction transaction1=session.beginTransaction();
		
		transaction1.begin();
		Query query = session.createQuery("From EmployeeDto");
		List<EmployeeDto> listofemp = query.list();
		System.out.println(listofemp);
		transaction1.commit();

		return listofemp;
	}

	//to get employee based on id
public EmployeeDto getEmployeebyId(int empid) {
		System.out.println("inside Dao Getemployeeby id"+empid);

		Configuration configuration=new Configuration();
		configuration.configure();
		
		SessionFactory factory=configuration.buildSessionFactory();	
		Session session=factory.openSession();
		Transaction transaction1=session.beginTransaction();
		
		transaction1.begin();
		EmployeeDto dto=(EmployeeDto) session.get(EmployeeDto.class, empid);
		
		transaction1.commit();

		return  dto;
	}


/*public List<EmployeeDto> getEmployeestree1() {
	Configuration configuration=new Configuration();
	configuration.configure();
	
	SessionFactory factory=configuration.buildSessionFactory();	
	Session session=factory.openSession();
	Transaction transaction = session.beginTransaction();
	transaction.begin();
	Query query = session
			.createQuery("From EmployeeDto where desgnation='ceo'");
	List<EmployeeDto> listofemp = query.list();
	System.out.println(listofemp);
	transaction.commit();

	return listofemp;
}
*/
/*public List<EmployeeDto> getEmployeesF(int managerId) {
	Configuration configuration=new Configuration();
	configuration.configure();
	
	SessionFactory factory=configuration.buildSessionFactory();	
	Session session=factory.openSession();
	Transaction transaction = session.beginTransaction();
	transaction.begin();
	Query query = session
			.createQuery("From EmployeeDto where manager.id=?");
	query.setInteger(0, managerId);
	List<EmployeeDto> listofemp = query.list();
	System.out.println(listofemp);
	transaction.commit();

	return listofemp;
}*/



	
}
